const accessCode1 = "VARIÁVEL";
const accessCode2 = "FUNÇÃO";
const accessCode3 = "BANCO DE DADOS";

function clues() {
    
    fill("white")
    textSize(15)
    text("R E V A I L V Á", 100,50)
    fill("lightblue")
    text("Dica: Sempre mudando, não constante!", 100,70)

    fill("white")
    textSize(15)
    text("Ç U N F O Ã", 700,150)
    fill("lightblue")
    text("Dica: Performa uma tarefa em particular!", 700,170)

    fill("white")
    textSize(15)
    text("B N D A O C A S D O E D", 100,250)
    fill("lightblue")
    text("Dica: Armazena todas as informações!", 100,270)

}